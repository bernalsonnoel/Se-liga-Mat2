// Você pode adicionar animações, mensagens ou interações aqui.
// Exemplo simples:
console.log("Seu portfólio carregou com sucesso!");
